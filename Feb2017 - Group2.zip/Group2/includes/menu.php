
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="downloads.php">Downloads</a></li>
                <li><a href="forum.php">Forum</a></li>
                <li><a href="dash.php">Contact us</a></li>
            </ul>
        </nav>
   