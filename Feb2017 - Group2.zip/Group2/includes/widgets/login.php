<div class="widget">
        <h2>Login</h2>
        <div class="inner">
         <form action="login.php" method="post">
         <ul>
         	<li> Username:<br>
         	<input type="text" name="username">  
         	</li>
         	<li>
         		 Password:<br>
         	<input type="password" name="password">
         	</li>
         	<li>
         	<input type="submit" value="Log in">
         	</li>
         	<li>
         	<a href="register.php">Register as Student</a>
            <li><a href="registert.php">Register as Teacher</a></li>
         		
         	</li>
         </ul>
            </form>
         </div>
</div>