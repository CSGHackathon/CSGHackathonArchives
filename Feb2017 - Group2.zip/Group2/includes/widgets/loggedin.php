<div class="widget">
        <h2>Hello, <?php echo $user_data['first_name'];?>!</h2>
        <div class="inner">
            <ul>
               <li>
                   <a href='logout.php'> Logout </a>
               </li>
               <li>
                   <a href='changepassword.php'> Change Password</a>
               </li>
              <!--  <li>
                   <a href='stat.html'> Dash</a>
               </li> -->
               <li>
                   <a href='regsub.php'>RegisterCourse</a>
               </li>
            <ul>
       </div>
</div>