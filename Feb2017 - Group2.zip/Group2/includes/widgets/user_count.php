<div class="widget">
     <h2> Users </h2>
     <div class="inner">
     	We currently have <?php //echo user_count(); ?> registerd users.
     </div>
</div>