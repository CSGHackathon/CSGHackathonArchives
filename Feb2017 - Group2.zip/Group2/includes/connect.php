<?php
 
 $connect = mysql_connect('localhost','root','');

 if(!$connect) {
 	die('could not connect to database');
 }
 mysql_select_db("project",$connect);
 
?>