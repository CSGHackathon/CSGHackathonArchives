<?php
$mysqli = new mysqli("localhost", "root", "", "lr");

/* check connection */
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}



if(isset($_GET['keywords'])) {
    $keywords = $mysqli ->escape_string($_GET['keywords']);
    $query = $mysqli->query("SELECT title FROM articles WHERE title LIKE '%{$keywords}%'");

    /* determine number of rows result set */
    $row_cnt = $query->num_rows;

    printf("Found %d results.\n", $row_cnt);

if($row_cnt){
      while($r = $query->fetch_object()) {
	?>
	 <div class = "result">
         <a href ='#'> <?php echo $r->title?></a>
	 </div>
	<?php  
}


}

    /* close result set */
    $query->close();
}

/* close connection */
$mysqli->close();
?>