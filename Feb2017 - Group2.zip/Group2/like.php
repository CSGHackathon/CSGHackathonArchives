<?php
require_once 'core/init.php';
if(isset($_GET['type'], $_GET['id'])) {
	$type  = $_GET['type'];
	$id = (int)$_GET['id'];
     
     switch($type){
         case 'upvote':
               $db -> query(" INSERT INTO articles_likes (user,article)
                     SELECT {$_SESSION['user_id']},{$id}
                     FROM movies
                     WHERE EXISTS (
                        SELECT id
                        FROM movies
                        WHERE id = {$id})
                       AND NOT EXISTS (
                            SELECT id
                            FROM articles_likes
                            WHERE user = {$_SESSION['user_id']}
                           AND article ={$id})
                         LIMIT 1   
                       
                	");
     
               break;
     }
}
header("Location:index.php")
?>