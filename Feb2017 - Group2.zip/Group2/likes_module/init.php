<?php
      session_start();
      $_SESSION['user_id'] = (int)1;

      $db =  new mysqli('localhost','root','','lr');


      //mysql_connect('localhost','root','');
      //mysql_select_db('lr');

?>