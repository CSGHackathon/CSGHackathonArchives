<html>
<head>
<title> Video</title>
</head>
<body>

<video width="320" height="240" controls>
 
   <source src="C:\Users\Akshay\Videos\Captures\mov_bbb.mp4	" type="video/mp4" />
</video>
<p>
  dsfcc sdv
</p>
</body>
</html>