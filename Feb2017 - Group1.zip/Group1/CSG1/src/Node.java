
import java.util.ArrayList;
import java.util.List;


/**
 * A node of any type. A node contains a data and links to it's children and it's parent.
 *
 * @param <T> The class type of the node
 */
public class Node<Integer> {
    private List<Node<Integer>> children;
    private Node<Integer> parent;
	private int i;

    public Node(int i) {
        this.i = i;
        this.children = new ArrayList<Node<Integer>>();
    }

    /**
     * Initialize a node with another node's data.
     * This does not copy the node's children.
     *
     * @param node The node whose data is to be copied.
     */
    public Node(Node<Integer> node) {
        this.i = node.getData();
        children = new ArrayList<Node<Integer>>();
    }

    /**
     *
     * Add a child to this node.
     *
     * @param child child node
     */
    public void addChild(Node<Integer> child) {
        child.setParent(this);
        children.add(child);
    }

    /**
     *
     * Add a child node at the given index.
     *
     * @param index The index at which the child has to be inserted.
     * @param child The child node.
     */
    public void addChildAt(int index, Node<Integer> child) {
        child.setParent(this);
        this.children.add(index, child);
    }

    public void setChildren(List<Node<Integer>> children) {
        for (Node<Integer> child : children)
            child.setParent(this);

        this.children = children;
    }

    /**
     * Remove all children of this node.
     */
    public void removeChildren() {
        this.children.clear();
    }

    /**
     *
     * Remove child at given index.
     *
     * @param index The index at which the child has to be removed.
     * @return the removed node.
     */
    public Node<Integer> removeChildAinteger(int index) {
        return children.remove(index);
    }

    /**
     * Remove given child of this node.
     *
     * @param childToBeDeleted the child node to remove.
     * @return <code>true</code> if the given node was a child of this node and was deleted,
     * <code>false</code> otherwise.
     */
    public boolean removeChild(Node<Integer> childToBeDeleted) {
        List<Node<Integer>> list = getChildren();
        return list.remove(childToBeDeleted);
    }

    public int getData() {
        return this.i;
    }

    public void setData(int data) {
        this.i = i;
    }

    public Node<Integer> getParent() {
        return this.parent;
    }

    public void setParent(Node<Integer> parent) {
        this.parent = parent;
    }

    public List<Node<Integer>> getChildren() {
        return this.children;
    }

    public Node<Integer> getChildAt(int index) {
    	//System.out.print(children.get(index).getData());
        return children.get(index);
    }

   /* @Override
   public boolean equals(Object obj) {
        if (null == obj)
            return false;

        if (obj instanceof Node) {
            if (((Node<?>) obj).getData().equals(this.i))
                return true;
        }

        return false;
    }

    @Override
    public String toString() {
        return this.i.toString();
    }
*/
}
