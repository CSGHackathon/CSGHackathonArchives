

import java.util.ArrayList;
import java.util.List;

/**
 * Generic n-ary tree.
 *
 * @param <T> Any class type
 */
public class Tree<integer> {

	private Node<integer> root;
    /**
     * Initialize a tree with the specified root node.
     *
     * @param root12 The root node of the tree
     */
    public Tree(Node<integer> root) {
        this.root= root;
    }

    /**
     * Checks if the tree is empty (root node is null)
     *
     * @return <code>true</code> if the tree is empty,
     * <code>false</code> otherwise.
     */
    public boolean isEmpty() {
        return root == null;
    }

    /**
     * Get the root node of the tree
     *
     * @return the root node.
     */
    public Node<integer> getRoot() {
        return root;
    }

    /**
     * Set the root node of the tree. Replaces existing root node.
     *
     * @param root The root node to replace the existing root node with.
     */
    public void setRoot(Node<integer> root) {
        this.root = root;
    }

    /**
     *
     * Check if given data is present in the tree.
     *
     * @param key The data to search for
     * @return <code>true</code> if the given key was found in the tree,
     * <code>false</code> otherwise.
     */
    public boolean exists(int key) {
        return find(root, key);
    }

    /**
     * Get the number of nodes (size) in the tree.
     *
     * @return The number of nodes in the tree
     */
    public int size() {
        return getNumberOfDescendants(root) + 1;
    }

    /**
     *
     * Get the number of descendants a given node has.
     *
     * @param node The node whose number of descendants is needed.
     * @return the number of descendants
     */
    public int getNumberOfDescendants(Node<integer> node) {
        int n = node.getChildren().size();
        for (Node<integer> child : node.getChildren())
            n += getNumberOfDescendants(child);

        return n;

    }

    private boolean find(Node<integer> node, int key) {
        boolean res = false;
        int x = node.getData();
        if (x == key)
            return true;

        else {
            for (Node<integer> child : node.getChildren())
                if (find(child, key))
                    res = true;
        }

        return res;
    }

    private Node<integer> findNode(Node<integer> node, int keyNode) {
        if (node == null)
            return null;
        if (node.getData() ==keyNode)
            return node;
        else {
            Node<integer> cnode = null;
            for (Node<integer> child : node.getChildren())
                if ((cnode = findNode(child, keyNode)) != null)
                    return cnode;
        }
        return null;
    }

    /**
     *
     * Get the list of nodes arranged by the pre-order traversal of the tree.
     *
     * @return The list of nodes in the tree, arranged in the pre-order
     */
    public ArrayList<Node<integer>> getPreOrderTraversal() {
        ArrayList<Node<integer>> preOrder = new ArrayList<Node<integer>>();
        System.out.print(getRoot().getData());
        buildPreOrder(root, preOrder);
        return preOrder;
    }

    /**
     *
     * Get the list of nodes arranged by the post-order traversal of the tree.
     *
     * @return The list of nodes in the tree, arranged in the post-order
     */
    public ArrayList<Node<integer>> getPostOrderTraversal() {
        ArrayList<Node<integer>> postOrder = new ArrayList<Node<integer>>();
        buildPostOrder(root, postOrder);
        return postOrder;
    }

    private void buildPreOrder(Node<integer> node, ArrayList<Node<integer>> preOrder) {
        preOrder.add(node);
        System.out.print("(");
        for (Node<integer> child : node.getChildren()) {
        	System.out.print(child.getData());
            buildPreOrder(child, preOrder);
        }
        System.out.print(")");
    }

    private void buildPostOrder(Node<integer> node, ArrayList<Node<integer>> postOrder) {
        
    	for (Node<integer> child : node.getChildren()) {
            buildPostOrder(child, postOrder);
        }
        postOrder.add(node);
    }

    /**
     *
     * Get the list of nodes in the longest path from root to any leaf in the tree.
     *
     * For example, for the below tree
     * <pre>
     *          A
     *         / \
     *        B   C
     *           / \
     *          D  E
     *              \
     *              F
     * </pre>
     *
     * The result would be [A, C, E, F]
     *
     * @return The list of nodes in the longest path.
     */
    public ArrayList<Node<integer>> getLongestPathFromRootToAnyLeaf() {
        ArrayList<Node<integer>> longestPath = null;
        int max = 0;
        for (ArrayList<Node<integer>> path : getPathsFromRootToAnyLeaf()) {
            if (path.size() > max) {
                max = path.size();
                longestPath = path;
            }
        }
        return longestPath;
    }


    /**
     *
     * Get the height of the tree (the number of nodes in the longest path from root to a leaf)
     *
     * @return The height of the tree.
     */
    public int getHeight() {
        return getLongestPathFromRootToAnyLeaf().size();
    }

    /**
     *
     * Get a list of all the paths (which is again a list of nodes along a path) from the root node to every leaf.
     *
     * @return List of paths.
     */
    public ArrayList<ArrayList<Node<integer>>> getPathsFromRootToAnyLeaf() {
        ArrayList<ArrayList<Node<integer>>> paths = new ArrayList<ArrayList<Node<integer>>>();
        ArrayList<Node<integer>> currentPath = new ArrayList<Node<integer>>();
        getPath(root, currentPath, paths);

        return paths;
    }

    private void getPath(Node<integer> node, ArrayList<Node<integer>> currentPath,
                         ArrayList<ArrayList<Node<integer>>> paths) {
        if (currentPath == null)
            return;

        currentPath.add(node);

        if (node.getChildren().size() == 0) {
            // This is a leaf
            paths.add(clone(currentPath));
        }
        for (Node<integer> child : node.getChildren())
            getPath(child, currentPath, paths);

        int index = currentPath.indexOf(node);
        for (int i = index; i < currentPath.size(); i++)
            currentPath.remove(index);
    }

    private ArrayList<Node<integer>> clone(ArrayList<Node<integer>> list) {
        ArrayList<Node<integer>> newList = new ArrayList<Node<integer>>();
        for (Node<integer> node : list)
            newList.add(new Node<integer>(node));

        return newList;
    }
    public static void main(String[] args) {
    	// Create a new Integer type node
    	Node<Integer> root = new Node<Integer>(1);
    	
    	Node<Integer> child1 = new Node<Integer>(2);
    	
    	Node<Integer> child2 = new Node<Integer>(3);
    	
    	Node<Integer> child3 = new Node<Integer>(4);
    	
    	Node<Integer> child11 = new Node<Integer>(5);
    	
    	Node<Integer> child12 = new Node<Integer>(6);
    	
    	Node<Integer> child21 = new Node<Integer>(7);
    	
    	Node<Integer> child31 = new Node<Integer>(8);

    	// Add a child
    	root.addChild(child1);
    	root.addChild(child2);
    	root.addChild(child3);

    	child1.addChild(child11);
    	child1.addChild(child12);
    	
    	//child2.addChild(child21);
    	
    	//child3.addChild(child31);
    	// Create a tree, providing the root node
    	Tree<Integer> tree = new Tree<Integer>(root);

    	// Get the pre-order traversal
    	System.out.println("Traversal of the tree");
    	List<Node<Integer>> preOrder = tree.getPreOrderTraversal();
    	
    	//System.out.println("Post Order Traversal of the tree");
    	//List<Node<Integer>> postOrder = tree.getPostOrderTraversal();
    	System.out.println("");
    	System.out.println("");
    	System.out.println("");
    	
    	System.out.println("Child at every index");
    	System.out.println("child at index 0 is " +root.getChildAt(0).getData());
    	System.out.println("child at index 1 is " +root.getChildAt(1).getData());
    	System.out.println("child at index 2 is " +root.getChildAt(2).getData());
    	//System.out.println("child at index 3" +root.getChildAt(3));
    	//System.out.println("child at index 4" +root.getChildAt(4));
    	//System.out.println("child at index 5" +root.getChildAt(5));
    	
    	
    }
    }