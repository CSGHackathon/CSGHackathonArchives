/**
 * Breakpoints.js
 *
 * @description :: TODO: You might write a short summary of how this model works and what it represents here.
 * @docs        :: http://sailsjs.org/documentation/concepts/models-and-orm/models
 */

module.exports = {
  schema: true,

  attributes: {
  		videoId: {
  			type: 'string',
  		},

  		videoTitle: {
  			type: 'string',
  		},

  		startPoint: {
  			type: 'integer',
  		},

  		endPoint: {
  			type: 'integer',
  		},

  		breakPointTitle: {
  			type: 'string',
  		},

      description: {
        type: 'string',
      },

      owner: {
        model: 'user',
        required: true
      }
  }
};

