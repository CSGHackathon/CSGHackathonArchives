/**
 * BreakpointssController
 *
 * @description :: Server-side logic for managing breakpointss
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {

	'new': function(req, res){
		res.view();
	},
	
	create: function(req, res, next){
		Breakpoints.create(req.params.all(), function breapointCreated(err, breakpoints){
			if (err) return next(err);
		  	if (!breakpoints) return next();


		  	res.redirect('/breakpoints/edit/' + breakpoints.id);
		});
	},

	show: function(req, res, next){
		Breakpoints.findOne(req.param('id'), function breakpointsFound(err, breakpoints){
		  	if (err) return next(err);
		  	if (!breakpoints) return next();

			res.view({
				breakpoints: breakpoints
			});
		});
	},

	index: function(req, res, next){
		Breakpoints.find(function breakpointssFound(err, breakpointss){
		  	if (err) return next(err);
			if (!breakpointss) return next();

			res.view({
				breakpointss: breakpointss
			});
		});
	},

	edit: function(req, res, next){
		Breakpoints.findOne(req.param('id'), function breakpointsFound(err, breakpoints){
		  	if (err) return next(err);
			if (!breakpoints) return next();

			res.view({
				breakpoints: breakpoints
			});
		});
	},

	update: function(req, res, next){
		Breakpoints.update(req.param('id'), req.params.all(), function breakpointsUpdated(err){
		  if (err) {
		    return redirect('/breakpoints/edit/'+ req.param('id'));
		  }

			res.redirect('/breakpoints/show/'+ req.param('id'));
		});
	},

	destroy: function(req, res, next){
		Breakpoints.findOne(req.param('id'), function breakpointsFound(err, breakpoint){
		  	if (err) return next(err);
		  	if (!breakpoint) return next();

			Breakpoints.destroy(req.param('id'), function breakpointsDestroyed(err){
				if (err) { return next(err); }
			});

			res.redirect('/user/show/'+ breakpoint.owner);
		});
	},
};

