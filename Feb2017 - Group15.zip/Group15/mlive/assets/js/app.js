
var videoId = "";

function init() {
  gapi.client.setApiKey("AIzaSyBr21qLOeJvAes1g2X3FLcHsqdelpBsDHM");
  gapi.client.load("youtube","v3", function () {

  });
}

function afterExecute(videoId, videoTitle) {
  	document.getElementById("videoId").value = videoId;
  	document.getElementById("videoTitle").value = videoTitle;
  	$("#form-youpush").submit();
}


$(document).ready(function(){
	$('.form-signin').validate({
    errorClass: "error",
    validClass: "valid",
		rules:{
			firstName: {
				required: true,
			},
      lastName: {
        required: true,
      },
			email: {
				required: true,
				email: true,
			},
			password: {
				minlength: 6,
				required: true,
			},
			confirmPassword: {
				minlength: 6,
				equalTo: "#password"
			}
		},

		success: function(element) {
			element.text('OK!').addClass('valid')
		}
	});

	$("#form-youtube").on("submit", function (e) {
	    e.preventDefault();
		    var request = gapi.client.youtube.search.list({
		      part : "snippet",
		      type : "video",
		      q : encodeURIComponent($("#search").val()).replace(/%20/g,"+"),
		      maxResults : 3,
		      order : "viewCount"
		    });

	    request.execute (function (response){
    		var videoId="";
    		var videoTitle="";
			console.log(response);
			var results = response.items;
	      	results.forEach(function (item) {
	          videoId = item.id.videoId;
	          videoTitle = item.snippet.title;
    		});
	      	afterExecute(videoId, videoTitle);
	    });
	});

  $("#breakpointsForm").on("submit", function(e){
	    e.preventDefault();
	    var startHours = $("#startHours").val();
	    var startMinutes = $("#startMinutes").val();
	    var startSeconds = $("#startSeconds").val();
	    var totalStartSeconds = (60 * 60 * startHours) + (60 * startMinutes) + (startSeconds*1);
	    var endHours = $("#endHours").val();
	    var endMinutes = $("#endMinutes").val();
	    var endSeconds = $("#endSeconds").val();
	    var totalEndSeconds = (60 * 60 * endHours) + (60 * endMinutes) + (endSeconds*1);
	    document.getElementById("startPoint").value = totalStartSeconds;
	    document.getElementById("endPoint").value = totalEndSeconds;
	    this.closest('form').submit();
  });

});

var node = "youtube-player";
  
  // Append the YouTube IFRAME API Script
  var youtube = document.createElement('script');
  youtube.type = "text/javascript";
  youtube.src = "//www.youtube.com/iframe_api";
  
  var s = document.getElementsByTagName('script')[0];
  s.parentNode.insertBefore(youtube, s);
  
  var player;
  
  // Read all the parameter of the DIV tag
  var params = document.getElementById(node);
  
  var startTime = params.getAttribute("startTime");
  var endTime = params.getAttribute("endTime");
  var videoID = params.getAttribute("videoID");
  var playerHeight = params.getAttribute("height");
  var playerWidth = params.getAttribute("width");
  

  // Prepare the YouTube Player
  // We set rel=0 and showinfo=1 to hide related videos & info bar

  function onYouTubeIframeAPIReady() {
    player = new YT.Player(node, {          
      height: playerHeight,
      width: playerWidth,
      playerVars: {'rel': 0, 'showinfo': 0, 'hidecontrols': 1 },
      events: {
        'onReady': loadVideo
      }
    });
  }

  // When the player is ready, we load the video
  // Using cueVideoById and not loadVideoById as the
  // former function will not autoplay the video.  
  function loadVideo(e) {      
    e.target.cueVideoById({ 
      videoId: videoID,
      startSeconds: startTime,
      endSeconds: endTime
    });
    e.target.playVideo();
  }

