# MLive

## About

MLive is a web application built using [Sails](http://sailsjs.org) web application framework. The application allows user to register to the web site, search for YouTube videos by entering keywords and allows the user to create breakpoints in the rendered video.

## Technologies Used
- Sails v0.12.11
- Node.js
- NPM (Node Package Manager)
- BootStrap 3
- HTML5 & CSS
- JavaScript
- YouTube Data API v3
- BcryptJS

## Purpose

The initial purpose of the application team was to explore open source live streaming and content management web application that could easily be leveraged for educational purposes.
The learning opportunities are tremendous on the web but finding relevant multimedia when needed could easily take a lot of time and commitment. With the help of YouTube Data API,
the application team was able to successfully implement the power to introduce breakpoints in YouTube videos. This allows the user to provide start and end time for a YouTube video
and the application automates the process of starting and ending the video within the specified time from the user. This data can be easily saved in the application, and same experience
can be shared with other users easily through the application by sharing the generated link.
