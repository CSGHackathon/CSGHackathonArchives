import { isEqual } from '../../../helpers/is-equal';
import { module, test } from 'qunit';

module('Unit | Helper | is equal');

// Replace this with your real tests.
test('it works', function(assert) {
  let result = isEqual(42);
  assert.ok(result);
});
