# Csgi Server Side Code

This folder contains the python server side code for the send and receive sms programs.