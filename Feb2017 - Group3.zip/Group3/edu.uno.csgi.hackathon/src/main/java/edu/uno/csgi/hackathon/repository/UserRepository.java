package edu.uno.csgi.hackathon.repository;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import edu.uno.csgi.hackathon.entities.User;
import edu.uno.csgi.hackathon.utils.ApplicationQueries;

//import edu.uno.csgi.hackathon.entities.User;



//public class UserRepository{
	
//}
public interface UserRepository extends JpaRepository<User,Serializable>{

	@Query(nativeQuery=true, value=ApplicationQueries.GETUSER)
    public User getDetails(String uname,String pass);

}	
	


