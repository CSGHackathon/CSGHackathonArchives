package edu.uno.csgi.hackathon.utils;

public class ApplicationQueries {

public static final String SELECTVIDEOS = "select * from Videos";

public static final String GETUSER = "select * from User where user_name=?1 and user_pass=?2";

}
