package edu.uno.csgi.hackathon.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.w3c.dom.DOMException;
import org.xml.sax.SAXException;


import edu.uno.csgi.hackathon.dto.VIdeoDTO;
import edu.uno.csgi.hackathon.entities.User;
//import edu.uno.csgi.hackathon.entities.Video;
import edu.uno.csgi.hackathon.service.SearchService;
import edu.uno.csgi.hackathon.utils.Storage.StorageFileNotFoundException;
import edu.uno.csgi.hackathon.utils.Storage.StorageService;

@Controller
public class SearchController {
	
	
	
	 private final StorageService storageService;

	    @Autowired
	    public SearchController(StorageService storageService) {
	        this.storageService = storageService;
	    }
	    @Autowired
		SearchService sersev;
		
	    
	    
	    
	    @RequestMapping(value="/upload",method = RequestMethod.GET)
	    public String listUploadedFiles(Model model,HttpServletResponse response) throws IOException {
	System.out.println("entered controller");
	        model.addAttribute("files", storageService
	                .loadAll()
	                .map(path ->
	                        MvcUriComponentsBuilder
	                                .fromMethodName(SearchController.class, "serveFile", path.getFileName().toString(),response)
	                                .build().toString())
	                .collect(Collectors.toList()));
	        System.out.println("before return");

	        //return "uploadForm";
	        return "welcome";
	    }
	    
	    
	
	
    @RequestMapping(value = "/video", method = RequestMethod.GET)
    public void loadVideoFile(
            HttpServletResponse response) throws IOException {
        FileInputStream inpstr = null;
        ServletOutputStream outstr = null;
        try {
            
            String Path = "/home/svishnubhotla/Desktop/abc.mp4";
            response.setContentLength((int) new File(Path).length());
            response.setContentType("video/mp4");
            inpstr = new FileInputStream(Path);
            outstr = response.getOutputStream();
            int value = IOUtils.copy(inpstr, outstr);
            IOUtils.closeQuietly(inpstr);
            IOUtils.closeQuietly(outstr);
            response.setStatus(HttpServletResponse.SC_OK);
        } catch (java.io.FileNotFoundException e) {
            //e.printStackTrace();
            response.setStatus(HttpStatus.NOT_FOUND.value());
        } catch (Exception e) {
           // e.printStackTrace();
            response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
        }finally{
        	inpstr.close();
        	outstr.close();
        }
    }
    
    
    @RequestMapping(value = "/load", method = RequestMethod.GET)
    public String showvideos() 
    {
		return "";
    	
    	
    }
    
    
    
    
    @GetMapping("/testfiles/{filename:.+}")
    @ResponseBody
    public void serveFile(@PathVariable String filename,
            HttpServletResponse response) {

        Resource file = storageService.loadAsResource(filename);
        
        
        FileInputStream inpstr = null;
        ServletOutputStream outstr = null;
        try {
            
            String Path = "/home/svishnubhotla/Desktop/"+file.getFilename();
            response.setContentLength((int) new File(Path).length());
            response.setContentType("video/mp4");
            inpstr = new FileInputStream(Path);
            outstr = response.getOutputStream();
            int value = IOUtils.copy(inpstr, outstr);
            IOUtils.closeQuietly(inpstr);
            IOUtils.closeQuietly(outstr);
            response.setStatus(HttpServletResponse.SC_OK);
        
        
        
        
        
        
       // return ResponseEntity
     //           .ok()
         //       .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\""+file.getFilename()+"\"")
           //     .body(file);
    }
        catch (java.io.FileNotFoundException e) {
            e.printStackTrace();
            response.setStatus(HttpStatus.NOT_FOUND.value());
        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
        }finally{

        }
    }
    
    @RequestMapping(value="/uploaded",method = RequestMethod.POST)
    public Object handleFileUpload(@RequestParam("file") MultipartFile file,
    							 

                                   RedirectAttributes redirectAttributes) throws IOException, DOMException, ClassNotFoundException, SAXException, ParserConfigurationException, URISyntaxException {

        storageService.store(file);

    	
    
    return "redirect:/upload";
    
    }
    
    @ExceptionHandler(StorageFileNotFoundException.class)
    public ResponseEntity handleStorageFileNotFound(StorageFileNotFoundException exc) {
        return ResponseEntity.notFound().build();
    }

    
    
    
    
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public String login(HttpServletResponse response,Model model,HttpServletRequest request){
		
    	HttpSession session =null;
		String username=null;
		String password=null;
		
		User usr = new User();
		username=request.getParameter("uname");
		password=request.getParameter("pass");		
		
		
		
		usr=sersev.getDetails(username, password);
		
		if(!("".equals(usr)))
			session=request.getSession(true);
		
		else 
			
			return "welcome";
		model.addAttribute("files", storageService
                .loadAll()
                .map(path ->
                        MvcUriComponentsBuilder
                                .fromMethodName(SearchController.class, "serveFile", path.getFileName().toString(),response)
                                .build().toString())
                .collect(Collectors.toList()));
		//System.out.println(usr.getUserEmail());
		if(usr != null){
		if(usr.getUserEmail().equals("admin"))///////email should be changed to user_role in future
			return "admin";
		else
			return "login";
		}
		else{
			return "welcome";
		}
					

    	
    	
    	
    	
    	
    }
    
    
    
    
    @RequestMapping(value = "/show", method = RequestMethod.GET)
    public String initial(
            HttpServletResponse response,Model model,HttpServletRequest request) {
    	
		HttpSession session =null;
		String username=null;
		String password=null;
		
		
		username=request.getParameter("uname");
		password=request.getParameter("pass");

		
		
		
		//session = request.getSession(true);

    	List <Object[]> vidList=null;
    	
		session=request.getSession(true);
		
		 //System.out.println(session.isNew()+"is new");

		  List<VIdeoDTO> list=new ArrayList<VIdeoDTO>();

    //	vidList = sersev.getVideos();
    	
    	System.out.println("size is "+vidList.size());
    	for (Object[] vid : vidList) {
    		
    		VIdeoDTO viddto = new VIdeoDTO();
    		
    		viddto.setVidID(vid[0].toString());
    		viddto.setVideo((vid[1].toString()+vid[2].toString()));
    		System.out.println(vid[0].toString());
    		list.add(viddto);
    		System.out.println(list.get(0).getVidID());
    		System.out.println((list.get(0).getVideo()));

    		

    	}   		
    	//for(Video vid : vidList)
    		System.out.println(list);
    //	model.addAttribute(list);
    	//request.setAttribute("videos",list);
session.setAttribute("videos",list);
    	
    	//model.addAttribute("videos", list);
    	
    	
    return "welcome";
    }
}
    
