package edu.uno.csgi.hackathon.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.uno.csgi.hackathon.entities.User;
import edu.uno.csgi.hackathon.repository.UserRepository;
//import edu.uno.csgi.hackathon.entities.Video;
import edu.uno.csgi.hackathon.repository.VideoRepository;
import edu.uno.csgi.hackathon.service.SearchService;


@Service
public class SearchServiceImpl implements SearchService{
	
	@Autowired
	VideoRepository vidrepo;
	
	@Autowired
	UserRepository userrepo;
	

	@Override
	public List<Object[]> getVideos() {

		List<Object[]> vidlist = null;
		
		try{
				
			//vidlist=vidrepo.selectvids();
			
			if("".equals(vidlist))
				return null;
					
		}
		
		catch (Exception ex){
			ex.printStackTrace();
		}
		
		
		
		return vidlist;
	}

	@Override
	public User getDetails(String uname, String pass) {
		// TODO Auto-generated method stub
		
		//userrepo.getdetails(String uname,String pass);
		
		
		return userrepo.getDetails(uname,pass);
	}

}
