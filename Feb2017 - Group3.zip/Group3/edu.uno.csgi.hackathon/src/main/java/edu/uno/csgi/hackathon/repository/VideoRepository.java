package edu.uno.csgi.hackathon.repository;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import edu.uno.csgi.hackathon.entities.Video;
//import edu.uno.csgi.hackathon.entities.Video;
import edu.uno.csgi.hackathon.utils.ApplicationQueries;

public interface VideoRepository  extends JpaRepository<Video,Serializable>{
	
	@Query(nativeQuery=true, value=ApplicationQueries.SELECTVIDEOS)
    public List<Object[]> selectvids();
//public class VideoRepository{
    }
