package edu.uno.csgi.hackathon.dto;

public class VIdeoDTO {

	String vidID;
	public String getVidID() {
		return vidID;
	}
	public void setVidID(String vidID) {
		this.vidID = vidID;
	}
	public String getVideo() {
		return video;
	}
	public void setVideo(String video) {
		this.video = video;
	}
	String video;
	
}
