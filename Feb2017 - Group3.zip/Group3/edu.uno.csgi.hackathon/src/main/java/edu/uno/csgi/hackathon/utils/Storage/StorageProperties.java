package edu.uno.csgi.hackathon.utils.Storage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;

//import edu.unomaha.ist.bioinformatics.bean.ApplicationBean;



@ConfigurationProperties("storage")
public class StorageProperties {

	
	//@Autowired
	//ApplicationBean appbean;
    /**
     * Folder location for storing files
     */
    private String location = "/home/svishnubhotla/Documents/upload-dir/"; 
    		//appbean.getUploadLoc();

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

}
