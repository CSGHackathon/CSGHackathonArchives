package edu.uno.csgi.hackathon.service;

import java.util.List;

import org.springframework.stereotype.Service;

import edu.uno.csgi.hackathon.entities.User;

//import edu.uno.csgi.hackathon.entities.Video;



public interface SearchService {
	
	public List<Object[]> getVideos();
	
	public User getDetails(String uname,String Pass);
	
	

}
