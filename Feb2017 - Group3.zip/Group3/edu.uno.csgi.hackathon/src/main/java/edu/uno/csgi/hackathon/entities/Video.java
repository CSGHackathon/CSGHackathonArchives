package edu.uno.csgi.hackathon.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the videos database table.
 * 
 */
@Entity
@Table(name="videos")
@NamedQuery(name="Video.findAll", query="SELECT v FROM Video v")
public class Video implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="vid_id")
	private int vidId;

	@Column(name="vid_location")
	private String vidLocation;

	@Column(name="vid_name")
	private String vidName;

	@Column(name="vid_uploaded_by")
	private String vidUploadedBy;

	public Video() {
	}

	public int getVidId() {
		return this.vidId;
	}

	public void setVidId(int vidId) {
		this.vidId = vidId;
	}

	public String getVidLocation() {
		return this.vidLocation;
	}

	public void setVidLocation(String vidLocation) {
		this.vidLocation = vidLocation;
	}

	public String getVidName() {
		return this.vidName;
	}

	public void setVidName(String vidName) {
		this.vidName = vidName;
	}

	public String getVidUploadedBy() {
		return this.vidUploadedBy;
	}

	public void setVidUploadedBy(String vidUploadedBy) {
		this.vidUploadedBy = vidUploadedBy;
	}

}