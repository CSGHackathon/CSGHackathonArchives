<html>
	<head>
		<title>Registration</title>
	</head>

	<body>
   		<table>
			<form action = "regValidation.php" method="post">
				Username:	<input type='text' name='username'><br>
				Password:	<input type='text' name='password'><br>
				<input type='submit'>
			</form>
		</table>
	</body>
</html>