import pandas as pd
import plotly.plotly as py
import plotly.graph_objs as go

#pd.read_csv("Lost.csv")

df=pd.read_table("Lost.csv")

