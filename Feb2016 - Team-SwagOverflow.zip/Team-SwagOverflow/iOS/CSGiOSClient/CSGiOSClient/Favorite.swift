//
//  Favorite.swift
//  CSGiOSClient
//
//  Created by Jacob Sanchez on 2/27/16.
//  Copyright © 2016 jacob.sanchez. All rights reserved.
//

import Foundation

class Favorite: NSObject {
    
    var id: Int?
    var item: Item?
    var user: User?
    var notifs_enabled: Bool?
    
}