//
//  Game.swift
//  CSGiOSClient
//
//  Created by Jacob Sanchez on 2/27/16.
//  Copyright © 2016 jacob.sanchez. All rights reserved.
//

import Foundation

class Game: Event {
    
    var homeTeam: Team?
    var awayTeam: Team?
    
}