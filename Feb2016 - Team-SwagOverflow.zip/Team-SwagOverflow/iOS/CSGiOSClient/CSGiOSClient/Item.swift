//
//  Item.swift
//  CSGiOSClient
//
//  Created by Jacob Sanchez on 2/27/16.
//  Copyright © 2016 jacob.sanchez. All rights reserved.
//

import Foundation

class Item: NSObject {
    
    var id: Int?
    var name: String?
    var logo_url: String?
    
}