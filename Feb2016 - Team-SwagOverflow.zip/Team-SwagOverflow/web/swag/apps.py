from django.apps import AppConfig


class SwagConfig(AppConfig):
    name = 'swag'
