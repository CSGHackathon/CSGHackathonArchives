package com.swagoverflow.androidclient.api.responses;

/**
 * Created by Mike on 2/27/2016.
 */
public class TeamDeletedResponse {
}
