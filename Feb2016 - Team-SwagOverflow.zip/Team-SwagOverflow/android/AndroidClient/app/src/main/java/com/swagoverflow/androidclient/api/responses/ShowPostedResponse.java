package com.swagoverflow.androidclient.api.responses;

import com.swagoverflow.androidclient.models.ShowFavorite;

/**
 * Created by Mike on 2/27/2016.
 */
public class ShowPostedResponse {
    private ShowFavorite favoriteshows;

    public ShowFavorite getFavoriteshows() {
        return favoriteshows;
    }
}
