package com.swagoverflow.androidclient.api.responses;

import com.swagoverflow.androidclient.models.Show;

import java.util.List;

/**
 * Created by Mike on 2/27/2016.
 */
public class GetShowsResponse {
    private List<Show> shows;

    public List<Show> getShows() {
        return shows;
    }
}
