package com.swagoverflow.androidclient.api.responses;

import com.swagoverflow.androidclient.models.TeamFavorite;

/**
 * Created by Mike on 2/27/2016.
 */
public class TeamPostedResponse {
    TeamFavorite favoriteteams;

    public TeamFavorite getFavoriteteams() {
        return favoriteteams;
    }
}
